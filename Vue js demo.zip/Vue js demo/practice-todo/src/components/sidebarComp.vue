<template>
  <div class="  bg-slate-200 h-full w-full text-center justify-center ">
    <ul class=" grid grid-cols-1 ">
        <li>DOCS</li>
        <li>HOME</li>
        <li>GALLERY</li>
        <li>ABOOUT</li>
        <li>NEW</li>
    </ul>
  </div>
</template>

<script>
export default {
            name: 'sidebarComp'
}
</script>

<style>
ul{
    @apply pt-6
}
li{
    @apply py-6
}

@media screen and (max-width:768px){
    .toggle-sidebar{
           
}
.toggle-todo{
           
}
}

</style>