<template>
  <div class=" flex">
  <div class=" w-1/4 toggle-sidebar" ref="sidebar">
    <Transition><sidebar-comp/></Transition>    
  </div>
  <button  type="submit" 
    class=" text-black font-semibold hover:bg-green-800  hover:text-white 
    px-4  py-4 sm:px-4 rounded bg-green-400 custom-class" 
    @click="toggleSidebar">Home</button>

  <div class=" divide divide-y gap-4 p-8 w-3/4 toggle-todo">
        <div class="grid lg:flex md:flex sm:grid  text-center justify-center divide-x gap-4 py-2">
   <form @submit.prevent="handleSubmit()" class="">
    <input type="text" placeholder="type here" v-model="typetext" ref="inputt"
    class="p-4  focus:bg-slate-200 focus:outline-none"/>
    <button  type="submit" 
    class=" text-black font-semibold hover:bg-green-800  hover:text-white px-12  py-4 sm:px-4 rounded bg-green-400 custom-class">Add</button>
   </form>
   <button  type="submit" @click="handleUpdate" 
   class=" text-black font-semibold hover:bg-gray-800  hover:text-white px-4  py-1 rounded bg-gray-400 custom-class">Update</button>
  </div>
  <div class="grid  text-center justify-center divide-x gap-4 py-2 lg:flex md:flex sm:grid" >
   <input type="search" v-model="searchdata" placeholder="search" 
   class="p-4  focus:bg-slate-200 focus:outline-none"/>
   <button  type="submit" @click="handleSearch"
   class=" text-black font-semibold hover:bg-yellow-700  hover:text-white px-4  py-2 rounded bg-yellow-300 custom-class">Search</button>
   <button  type="submit" @click="handleSort" 
   class=" text-black font-semibold hover:bg-yellow-700  hover:text-white px-4  py-2 rounded bg-yellow-300 custom-class">Sort</button>
  </div>
  <div class=" h-60 overflow-auto">
   <div v-for="(item,index)  in searchFunc" :key="index" class="my-1" ref="list">
       {{index}} - {{item}} 
       <button @click="handleEdit(index)"
       class=" text-black font-semibold hover:bg-blue-800  hover:text-white px-4  py-2 rounded bg-blue-300 mx-1 custom-class">Edit</button>
       <button @click="handleDelete(index)"
       class=" text-black font-semibold hover:bg-red-800  hover:text-white px-4  py-2 rounded bg-red-300 mx-1 custom-class">Delete</button>
   </div>
  </div>
  </div>
</div>
</template>

<script>
import { Transition } from 'vue'
import sidebarComp from './sidebarComp.vue'
export default {
  components: { sidebarComp, Transition },
        name: 'todoComp',
        data(){
          return{
            typetext:'',
            textArray : [],
            itemIndex : '',
            editText : '',
            id : 0,
            searchdata:'',
            showsidebar : true
            //inputt : this.$refs.inputt.style.color  = 'red'
          }
        },
        
        methods:{
          handleSubmit(){
           // console.log(this.typetext)
           let a = this.$refs.inputt.value
           console.log(a)
           // this.$refs.inputt.style.color  = 'red'
            if(this.typetext.length == 0){
              return null
            }
          //  this.textArray.push({idObj:new Date().getTime().toString() , nameObj:this.typetext})
          this.textArray.push(this.typetext)
          console.log(this.id += 1)
            this.typetext = ''
          },
          handleDelete(index){
            this.textArray.splice(index,1)
          },
          handleEdit(index){
           // console.log(index)
            this.typetext = this.textArray[index]
            this.itemIndex = index
            console.log(this.typetext,this.itemIndex)
          },
          handleUpdate(){
           this.textArray[this.itemIndex]=this.typetext
           
          },
          // handleSearch(){
          //    return this.textArray.filter(item=>{
          //       return item.toLowerCase().includes(this.searchdata.toLowerCase())
          //     })
          //    // console.log('hello')
          // },
          handleSort(){
            let a = this.textArray.sort()
            return a ,
            console.log(a)
          },
          // toggleSidebar(){
          //   console.log('sidebar')
          //   this.showsidebar = !this.showsidebar
          //   if(this.showsidebar){
          //       console.log('true')

          //   }else{
          //     console.log('false')
          //   }
          //    // this.$refs.sidebar.style.display = 'block'
          // },
          toggleSidebar() {
      if (this.showsidebar == true) {
        console.log('true')
        document.getElementsByClassName('toggle-sidebar')[0].style.display = 'none '
      //  document.getElementsByClassName('toggle-todo')[0].style.width = '85%'
       this.showsidebar = false
       
      } else {
        console.log('false')
        document.getElementsByClassName('toggle-sidebar')[0].style.display = 'block '
        this.showsidebar = true
      }
    },
        },
        computed:{
          searchFunc(){
            
            // return this.textArray.filter((item)=>{
            //   return item.toLowerCase().includes(this.searchdata.toLowerCase())
            // })
             return this.textArray.filter(item=>{
               return item.toLowerCase().match(this.searchdata.toLowerCase())
              
            }) 
          },
          // sortFunc(){
          //   return this.textArray.sort()
          // }
        },
        mounted(){
          console.log(this.showsidebar)
        }
}
</script>

<style>
.custom-class{
  @apply font-serif hover:shadow-lg hover:shadow-gray-900 shadow-xl shadow-gray-300 
}
 @media screen and (max-width: 700px) {
  .toggle-sidebar{
    display: none !important;
    position: absolute;
  }
}
/* .toggle-sidebar{
  position: relative;
  display: block !important;
}  */
</style>