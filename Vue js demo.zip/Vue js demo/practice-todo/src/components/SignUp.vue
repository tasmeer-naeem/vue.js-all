<template>
    <div class="">
      <input type="text"  v-model="fullname" placeholder="Enter Name"/>
       <input type="text" v-model="email" placeholder="Enter Email"/>
        <input type="password" v-model="password" placeholder="Enter Password"/>
        <button v-on:click='signup()' >Sign Up</button>
        <h3><router-link to="/todo" >Login</router-link>  </h3>
        <h3><router-link to="/menu" >Menu</router-link>  </h3>
  </div>
</template>

<script>
export default {
            name : "SignUp",
            data(){
                return{
                    fullname:'',
                    email:'',
                    password:''

                }
            },
            methods:{
                signup(){
                    console.log('signup')
                    console.log(this.fullname,this.email,this.password)
                }
            }
        
}
</script>

<style>

</style>