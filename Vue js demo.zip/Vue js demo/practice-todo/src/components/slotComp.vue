<template>
  <div>
  <slot/>
  <slot><h2>slot default</h2></slot>
  <header class=" text-4xl text-green-900">
    <slot name="header" ></slot>
  </header>
  <main class=" text-lg text-orange-900">
    <slot name="main"></slot>
  </main>
  <footer class=" text-xl text-blue-900">
    <slot name="footer"></slot>
  </footer>
  </div>
</template>

<script>
export default {
            name: "slotComp"
}
</script>

<style>

</style>