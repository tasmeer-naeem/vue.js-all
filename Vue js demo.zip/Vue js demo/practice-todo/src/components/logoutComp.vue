<template>
  <div >
    <slot-comp>slot_define</slot-comp>
    <slot-comp/>
    <slot-comp>
    <template v-slot:header>header 1</template>
    <template v-slot:main>main 1</template>
    <template v-slot:footer>footer 1</template>
  </slot-comp>
  <slot-comp>
    <template v-slot:header>header 2</template>
    <template v-slot:main>main 2</template>
    <template v-slot:footer>footer 2</template>
  </slot-comp>
  </div>
</template>

<script>
import slotComp from './slotComp.vue'
export default {
  components: { slotComp },
        name : 'logoutComp'
}
</script>

<style>

</style>