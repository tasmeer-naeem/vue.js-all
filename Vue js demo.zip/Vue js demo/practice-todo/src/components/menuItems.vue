<template>
    <div>
    <div v-for="(i,index) in  this.arr" :key="index">
        {{i}}
        
    </div>
    <button @click="loadmore">add more </button>
</div>
</template>

<script>

export default {
        name :  "menuItems",
        data(){
            return{
                arrayy:[
                    'a','b','c','a','b','c', //'a','b','c','a','b','c','a','b','c','a','b','c','a','b','c',
                ],
                visibleitems : 4,
                count : 0,
                arr : [],
            }
        },
        methods:{
             loadmore(){
                //this.arr.push(this.arrayy)
                this.arr = [...this.arrayy]
                console.log('hello',this.arr)
            }
    },
        mounted(){
            //this.loadmore()
        }
}
</script>

<style scoped>

</style>