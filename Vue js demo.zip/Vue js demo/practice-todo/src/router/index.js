import { createRouter } from "vue-router";
import { createWebHistory } from "vue-router";
import  todoPage from '../pages/todoPage.vue'
import logoutComp from '../components/logoutComp.vue'
import SignUp from '../components/SignUp.vue'
import menuItems from '../components/menuItems.vue'

const routes = [
    {
        component : todoPage,
        path : '/todo',
        name : 'todoPage'
    },
    {
        component : SignUp,
        path : '/',
        name : 'Signup'
    },
    {
        component : logoutComp,
        path : '/logout',
        name : 'logoutComp'
    },
    {
        component : menuItems,
        path : '/menu',
        name : 'menuItems'
    },

]

const router = createRouter ({
    history : createWebHistory(),
    routes
})

export default router