

export default signup = async(fullname,email,password)={
        return await axios.post('')
}