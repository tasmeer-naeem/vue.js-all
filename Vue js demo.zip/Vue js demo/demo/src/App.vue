<template>
<div>
  <!-- <emoji-picker/> -->
  <!-- <chat-box/> -->
  <modal-box/>
</div>
  <!-- <img alt="Vue logo" src="./assets/logo.png">
  <HelloWorld msg="Welcome to Your Vue.js App"/> -->
</template>

<script>
import ModalBox from './components/ModalBox.vue'
//import ChatBox from './components/ChatBox.vue'
//import EmojiPicker from './components/EmojiPicker.vue'
//import HelloWorld from './components/HelloWorld.vue'

export default {
  name: 'App',
  components: {
    ModalBox
 //   EmojiPicker,
  //  ChatBox
   // HelloWorld
  }
}
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
