<template>
<div>
  <div @click="closeModal">
      <textarea id="example1"></textarea>
      <p id='demo'></p>
      <p id='box' class="show">close window</p>
      <div> <button @click='toggleEmoji'  id='popup-trigger'>toggleEmoji</button> </div>
  </div>
   <div v-if="showEmoji"  id='boxx'>show emojjisss
        <button  @click='toggleEmoji2'>click here</button>
    </div>
         <div v-if="showEmoji2">
            show emojjisss
        </div>
</div>
</template>

<script>
 const popupQuerySelector = "#box";
  const popupEl = document.querySelector(popupQuerySelector);
 // const popupBttn = document.querySelector("#popup-trigger");

//   popupBttn.addEventListener("click", () => {
//     setTimeout(() => {
//       if (!popupEl.classList.contains("show")) {
//         // Add class `show` to filterList element
//         popupEl.classList.add("show");
//       }
//     }, 250);
//   });

 // const isClosest = e.target.closest(popupQuerySelector);
  document.addEventListener("click", (e) => {
  // Check if the filter list parent element exist
  const isClosest = e.target.closest(popupQuerySelector);

  // If `isClosest` equals falsy & popup has the class `show`
  // then hide the popup
  if (!isClosest && popupEl.classList.contains("show")) {
    popupEl.classList.remove("show");
  }
});


// document.addEventListener('click', function handleClickOutsideBox(event) {
//   const box = document.getElementById('box');

//   if (box.contains(event.target)) {
//     box.style.display = 'none';
//   }
// });

export default {
    name:"EmojiPicker",
    data(){
        return{
            showEmoji:false,
            showEmoji2:false
        }
    },

    methods:{
        toggleEmoji(){
        
            console.log("emoji")
            this.showEmoji = !this.showEmoji
        //  window.addEventListener("click", function() {
        document.getElementById("demo").innerHTML = "Hello World"; 
        },
         toggleEmoji2(){
         
            console.log("emoji2")
            this.showEmoji2 = !this.showEmoji2
        },
        closeModal(){
            window.closed
        }
    }
}
</script>

<style>

</style>