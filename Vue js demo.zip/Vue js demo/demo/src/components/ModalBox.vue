<template>
  <div>
    ModalBox
      <div v-if="showModal">
        <!-- <select v-for="(i,index) in options" :key="index" @change="onChange($event)">
            <option value="1">{{i.option1}}</option>
            <option value="2">{{i.option2}}</option>
            <option value="3">{{i.option3}}</option>
            <option value="4">{{i.option4}}</option>
        </select> -->

        <select v-model="selected">
        <option selected value="" disabled>Select Indicator</option>
       <option v-for="product in products"  :key="product.id"
       :value="{ id: product.id, text: product.name }">
       {{ product.name }}
       </option>
        </select>

         <div v-if="addinputrows">
         <div v-for="item in addemptyfields" :key='item'>
        <input type="text" v-model="typeText"/>
       
        </div>
        </div>
        <button @click="addInputFunc">add row</button>
        <button @click="saveChangesFunc">save changes</button>
      </div>
      {{selected.id}} - {{selected.text}}

        <div v-if="getModal">
        <select>
            <option value=""></option>
            <option value=""></option>
            <option value=""></option>
            <option value=""></option>
        </select>
       
        <input type="text"/>
        <button>addd row</button>
        <button>saved changes</button>
      </div>

        <div>
            <div v-for="(item,index) in indicatorArray" :key="index"  style="display:flex">
            <div>{{item}}</div>
            <div @click="getModalFunc">+</div>
            <div v-for="(item,index) in parameterArray" :key="index" >
            <div>{{item}}</div>
            </div>
            </div>
        </div>

        <button @click="showModalFunc">add filter</button>
  </div>
</template>

<script>
export default {
        name:'ModalBox',
        data(){
            return{
                showModal:false,
                getModal:false,
                addinputrows:false,
                addemptyfields:[],
                selectIndicator:'',
                typeText:'',
                selectParameter:'',
                indicatorArray:[],
                parameterArray:[],

                    selected:'',
                  products: [
                    {id: 1, name: 'MACD'},
                    {id: 2, name: 'RSI'},
                    {id: 3, name: 'ROC'}
                    ],

                // options:[
                //     { option1 : 'MACD',
                //       option2 : 'RSI',
                //       option3 : 'ROC',
                //       option4 : 'BBAND',
                //     }
                //     ],

                row:[
                    {id:'' , indicator:'' , parameter:[]}
                    ]
            }
        },
        methods:{
            showModalFunc(){
                console.log("showModalFunc")
                this.showModal = true
                
            },
            // onChange(event){
            // var id = event.target.value;
            // var name = event.target.options[event.target.options.selectedIndex].text;
            // console.log('id ',id );
            // console.log('name ',name );
            // },
            addInputFunc(){
                    console.log("addInputFunc")
                    this.addinputrows = true
                    this.addemptyfields.push(this.addinputrows)
            },
             saveChangesFunc(){
                
              //  this.selectValue = this.name
                this.selectIndicator = this.selected.text
                this.selectParameter = this.typeText
                this.indicatorArray.push(this.selectIndicator)
                this.parameterArray.push(this.selectParameter)
                console.log("saveChangesFunc",this.selectIndicator, this.selectParameter)
            },


            getModalFunc(){
                console.log("getModalFunc")
                this.getModal = true
            },
           
        },
        // watch:{
        //     row(){
        //          console.log(this.row)
        //     }
        // }
}
</script>

<style>


</style>