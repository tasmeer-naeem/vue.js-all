<template>
<div class="maindv">
  <div @click="clickOutside() "  class="maindvchild1">
    <div class="container mx-auto">
      <div v-if="isAuthenticated" class="border rounded">
        <div>
          <div class="w-full h-full">
            <div class="flex justify-between">
              <div class="relative flex items-center p-3">
                <span class="block ml-2 font-bold text-gray-600"
                  >Group Name</span
                >
              </div>

              <button
                @click="handleLogOut()"
                type="button"
                class="py-2.5 px-8 mt-2 mr-2 mb-2 text-xs font-medium text-gray-900 focus:outline-none bg-gray rounded-lg border border-gray-200 hover:bg-gray-100 hover:text-blue-700 focus:z-10 focus:ring-4 focus:ring-gray-200 dark:focus:ring-gray-700 dark:bg-gray-800 dark:text-gray-400 dark:border-gray-600 dark:hover:text-white dark:hover:bg-gray-700"
              >
                Logout
              </button>
            </div>

            <div class="msgdv">
            <div class="relative w-full p-6 overflow-y-auto h-[38rem]" id="chatbox">
              <ul class="space-y-2">
                <div v-for="message in messageData" :key="message.name">
                  <li
                    class="flex justify-start"
                    v-if="message.type == 'message' && !message.currentUser"
                  >
                    <div
                      class="relative max-w-xl px-4 py-2 text-gray-700 rounded shadow"
                    >
                      <span class="block break-words">
                        {{ message.name }} : {{ message.msg }}</span
                      >

                      <span
                        class="text-gray-400 text-xs font-medium inline-flex items-center rounded dark:bg-blue-200 dark:text-blue-800"
                      >
                        <timeago :datetime="message.time" :autoUpdate="5" />
                        <!-- 2 minutes ago -->
                      </span>
                    </div>
                  </li>

                  <li
                    v-if="message.type == 'message' && message.currentUser"
                    class="flex justify-end"
                  >
                    <div
                      class="relative max-w-xl px-4 py-2 text-gray-700 bg-gray-100 rounded shadow"
                    >
                      <span class="block break-words">{{ message.msg }}</span>

                      <span
                        class="text-gray-400 text-xs font-medium inline-flex items-center rounded dark:bg-blue-200 dark:text-blue-800"
                      >
                        <timeago
                          includeSeconds
                          :datetime="message.time"
                          :autoUpdate="true"
                        />
                        <!-- 2 minutes ago -->
                      </span>
                    </div>
                  </li>

                  <div
                    v-if="message.type == 'notification'"
                    class="flex items-center justify-center text-justify p-2 mb-2 text-sm text-blue-300 font-bold font-sans rounded-lg dark:bg-blue-200 dark:text-blue-800"
                  >
                    <div>
                      <span class="font-medium"></span>
                      {{ message.msg }}
                    </div>
                  </div>
                </div>
              </ul>
            </div>
            </div>

            <div class="dvone">
            <div
              class="flex items-center justify-between w-full p-3 border-t border-gray-300  "
            >
              <!-- <button @click="selectEmoji"  id="clickaway">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  class="w-6 h-6 text-gray-500"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <path
                    stroke-linecap="round"
                    stroke-linejoin="round"
                    stroke-width="2"
                    d="M14.828 14.828a4 4 0 01-5.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
                  />
                </svg>
              </button> -->

              <input
                type="text"
                placeholder="Message"
                v-model="textt"
                class="block w-full py-2 pl-4 mx-3 bg-gray-100 rounded-full outline-none focus:text-gray-700"
                name="message"
                required
                v-on:keyup.enter="submitMessage"
              />

              <button @click="submitMessage">
                <svg
                  class="w-5 h-5 text-gray-500 origin-center transform rotate-90 fill-blue-500 hover:fill-cyan-700"
                  xmlns="http://www.w3.org/2000/svg"
                  viewBox="0 0 20 20"
                >
                  <path
                    d="M10.894 2.553a1 1 0 00-1.788 0l-7 14a1 1 0 001.169 1.409l5-1.429A1 1 0 009 15.571V11a1 1 0 112 0v4.571a1 1 0 00.725.962l5 1.428a1 1 0 001.17-1.408l-7-14z"
                  />
                </svg>
              </button>

               <!-- <Transition name="slide-fade" id="boxx" ref="inner-rect">
              <div v-if="showEmoji" class="emojiStyles popup" id="try" @click.self="close">
                <EmojiPicker :native="true" @select="onSelectEmoji" class="show" />
             
              </div>
              </Transition> -->

            </div>            
          </div>
        </div>
       
      </div>
    </div>
      <!-- <div v-else>
        <LoginForm v-on:authenticated="isAuth($event)" :room="roomName" />
      </div> -->
    </div>
  
  
  </div>
  <div class="dvtwo">
      <input     style="padding : 8px"
                type="text"
                placeholder="Message"
                v-model="text"
                class="block w-full py-2 pl-4 mx-3 bg-gray-100 rounded-full outline-none focus:text-gray-700"
                name="message"
                required
                v-on:keyup.enter="submitMessage"
              />
   <button @click="selectEmoji"   class="float-left dvtwobtn">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  class="w-6 h-6 text-gray-500"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <path
                    stroke-linecap="round"
                    stroke-linejoin="round"
                    stroke-width="2"
                    d="M14.828 14.828a4 4 0 01-5.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
                  />
                </svg>
    </button>
      <Transition name="slide-fade"  class="dvtwopopup">
              <div v-if="showEmoji" class="emojiStyles" >
                <EmojiPicker :native="false"  @select="onSelectEmoji" class="show dvtwopopupp" />
              </div>
      </Transition>
    </div>
    
</div>
</template>

<script>

//import LoginForm from "./LoginForm.vue";
import EmojiPicker from "vue3-emoji-picker";
import "/node_modules/vue3-emoji-picker/dist/style.css";

export default {
  name: "ChatBox",

  components: {
    EmojiPicker,
   // LoginForm,
  },
  
  data() {
    return {
      userEmail: "",
      roomName: "",
      isAuthenticated: false,
      textt:{
        emoji: [],
      text: "",
      },
      showEmoji: false,
      messageData: [
        {
          time: "2021-09-01",
          name: "Hassaan",
          msg: "Hi",
          currentUser: true,
          email: "",
          type: "message",
        },
        {
          time: "2021-09-01",
          name: "Hassaan",
          msg: "How are you? 🤔",
          currentUser: true,
          email: "",
          type: "message",
        },
        {
          time: "2021-09-01",
          name: "Adil",
          msg: "I'm good thanks.",
          currentUser: false,
          email: "",
          type: "message",
        },
        {
          time: "2021-09-01",
          name: "Adil",
          msg: "Tom has joined the Chat Room",
          currentUser: false,
          email: "",
          type: "notification",
        },
      ],
    };
  },
  created() {
    if (localStorage.getItem("isAuthenticated")) {
      this.isAuthenticated = true;
    } else {
      this.isAuthenticated = false;
    }
    // this.roomName = this.$route.params.id;
    console.log(this.roomName);
  },
//   mounted() {
//     // devops
//     console.log("this.$socketApi", this.$socketApi);

//     this.$socketApi.on("user-connected", (data) => {
//       if(this.roomName === data.room){
// const obj = {
//         time: "-",
//         name: "-",
//         msg: `${data.name} has joined the Chat Room !`,
//         email: "-",
//         type: "notification",
//       };
//       this.messageData.push(obj);
//       }
      
//       console.log("user-connected", data);
//     });

//     this.$socketApi.on("user-disconnected", (data) => {
//       if(this.roomName === data.room){
// const obj = {
//         time: "-",
//         name: "-",
//         msg: `${data.name} has left the Chat Room !`,
//         email: "-",
//         type: "notification",
//       };
//       this.messageData.push(obj);
//       }
      
//       console.log("user-disconnected", data);
//     });

//     this.$socketApi.on("chat-message", (data) => {
//       console.log("chat-message", data);
//       const obj = {
//         time: data.message.time,
//         name: data.message.name,
//         msg: data.message.msg,
//         email: data.message.email,
//         currentUser: false,
//         type: "message",
//       };
//       this.messageData.push(obj);
//     });

//     // this.$socketApi.on('demo', data => {
//     //   console.log('user-connected', data)
//     // })
//   },

  methods: {
     clickOutside(){
       this.showEmoji = false
       console.log('Clicked outside. ')
},
    handleLogOut() {
      localStorage.removeItem("isAuthenticated");
      localStorage.removeItem("userEmail");
      this.isAuthenticated = false;
    },
    isAuth(val) {
      if (val) {
        localStorage.setItem("isAuthenticated", true);
        this.isAuthenticated = true;
      } else {
        this.isAuthenticated = false;
      }
    },
    scrollToEnd() {
      var chatList = document.getElementById("chatbox");
      chatList.scrollTop = chatList.scrollHeight;
    },

    onSelectEmoji(obj) {
      this.textt = this.textt.text + obj.i;
      this.textt.emoji.push(obj.i);
      console.log(this.emoji);
      console.log(obj);
    },

    selectEmoji() {
      this.showEmoji = !this.showEmoji;
      console.log("emojiii");
    },

    submitMessage() {
      if (this.text) {
        // const urlify = (text) => {
        //   const urlRegex = /(https?:\/\/[^\s]+)/g;
        //   return text.replace(urlRegex, (url) => {
        //     return `<a href="${url}">${url}</a>`;
        //   });
        // };

        // const convertedString = urlify(this.text);
        // this.text = convertedString;
        // console.log(moment(new Date()).format("LLLL"));
        let obj = {
          // time: moment(new Date()).format("LLLL"),
          time: new Date(),
          name: localStorage.getItem("userEmail"),
          msg: this.text,
          currentUser: false,
          email: localStorage.getItem("userEmail"),
          type: "message",
        };
        console.log("before emmit:", obj);
        this.$socketApi.emit("send-chat-message", this.roomName, obj);
        obj = { ...obj, currentUser: true };
        console.log("after emmit:", obj);
        this.messageData.push(obj);
        this.text = "";
        setTimeout(()=> {
          this.scrollToEnd();
        },100)
      }
    },
  },

};
</script>

<style>
.slide-fade-enter-active {
  transition: all 0.5s ease-in-out;
}
.slide-fade-leave-active {
  transition: all 0.3s ease-in
}
.slide-fade-enter-from,
.slide-fade-leave-to {
  transform: translateX(-90px);
  
}
.dvone{
  display:flex;
 float: right;
 width:97%;
 position:relative
}
.dvtwo{
    color:blue;
    float:right;
    
}
.dvtwobtn{
  margin-right:4px;
  margin-left: 0px;
  margin-top:20px;
}
.dvtwopopup{
 margin-left: 4%; 
  position: absolute;
  top: 340px;
  bottom: 30px;
}
.dvtwopopupp{
  width:60vh;
}
@media screen and (max-width: 800px) {
  .dvtwobtn{
    right:10px;
  margin-top:20px;
  }
}
@media screen and (max-width: 800px) {
 .slide-fade-enter-from,
.slide-fade-leave-to {
  transform: translateX(-10px);
}
.dvtwopopup{
 left:20px
}
}
@media screen and (max-width: 500px) {
.dvtwopopupp{
  width:45vh; 
}
}
</style>
