
var a =  "testing"
console.log("js file",a)

