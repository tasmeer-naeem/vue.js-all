
import axios from "axios";
export const getHistoricalData = (symbol) => {
    return axios
      .post("http://dev-api.traderverse.io/cosmos/historical", {
        key: 'L2ykq39NTxeQ84yr' , //process.env.VUE_APP_API_KEY,
        symbol,
      })
      .then((response) => {
        return response;
      });
  };
  
 
  