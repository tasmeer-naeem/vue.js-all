<template>
  <div>
    <apexchart width="500" type="candlestick" :options="chartOptions" :series="series"></apexchart>
    <apexchart width="500"  :options="chartOptionsBasicbar" :series="seriesBasicbar"></apexchart>
  </div>
</template>

<script>
import {getHistoricalData} from '@/components/store'
import VueApexCharts from "vue3-apexcharts";
export default {
  name: 'App',
  components: {
    apexchart : VueApexCharts,
  },
  data(){
      return{          
          series: [{
            data: [{
                x: new Date(1538778600000),
                y: [6629.81, 6650.5, 6623.04, 6633.33]
              },
              {
                x: new Date(1538780400000),
                y: [6632.01, 6643.59, 6620, 6630.11]
              },
              {
                x: new Date(1538782200000),
                y: [6630.71, 6648.95, 6623.34, 6635.65]
              },
              {
                x: new Date(1538784000000),
                y: [6635.65, 6651, 6629.67, 6638.24]
              },
              {
                x: new Date(1538785800000),
                y: [6638.24, 6640, 6620, 6624.47]
              },
              {
                x: new Date(1538787600000),
                y: [6624.53, 6636.03, 6621.68, 6624.31]
              },
              {
                x: new Date(1538789400000),
                y: [6624.61, 6632.2, 6617, 6626.02]
              },
              {
                x: new Date(1538791200000),
                y: [6627, 6627.62, 6584.22, 6603.02]
              },
              {
                x: new Date(1538793000000),
                y: [6605, 6608.03, 6598.95, 6604.01]
              },
              {
                x: new Date(1538794800000),
                y: [6604.5, 6614.4, 6602.26, 6608.02]
              },
              {
                x: new Date(1538796600000),
                y: [6608.02, 6610.68, 6601.99, 6608.91]
              },
              ]
          }],
          chartOptions: {
            chart: {
              type: 'candlestick',
              height: 290,
              id: 'candles',
              toolbar: {
                autoSelected: 'pan',
                show: true
              },
              zoom: {
                enabled: true
              },
            },
            plotOptions: {
              candlestick: {
                colors: {
                  upward: '#3C90EB',
                  downward: '#DF7D46'
                }
              }
            },
            xaxis: {
              type: 'datetime'
            }
          },
          
          seriesBar: [{
            name: 'volume',
            data: [23,43,343,65,668,21,23,32]
          }],
          chartOptionsBar: {
            chart: {
              height: 160,
              type: 'bar',
              brush: {
                enabled: true,
                target: 'candles'
              },
              selection: {
                enabled: true,
                xaxis: { 
                 // categories: ['Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct'],
                  min: new Date('20 Jan 2017').getTime(),
                  max: new Date('10 Dec 2017').getTime()
                },
                fill: {
                  color: '#ccc',
                  opacity: 0.4
                },
                stroke: {
                  color: '#0D47A1',
                }
              },
            },
            dataLabels: {
              enabled: true
            },
            plotOptions: {
              bar: {
                columnWidth: '80%',
                colors: {
                  ranges: [{
                    from: -1000,
                    to: 0,
                    color: '#F15B46'
                  }, {
                    from: 1,
                    to: 10000,
                    color: '#FEB019'
                  }],
            
                },
              }
            },
            stroke: {
              width: 0
            },
            xaxis: {
              type: 'datetime',
              axisBorder: {
                offsetX: 13
              }
            },
            yaxis: {
              labels: {
                show: true
              }
            }
          },
          chartOptionsBasicbar: {
        chart: {
          id: "vuechart-example",
        },
        colors:['red','black','yellow','purple'],
        
        xaxis: {
          categories: [1991, 1992, 1993, 1994, 1995, 1996, 1997, 1998],
        },
        distributed:{
          enabled : false
        },
        dataLabels: {
          enabled: false
        },
          },
          seriesBasicbar: [
          {
            name: "series-1",
            type: "line",
            data: [30, 40, 35, 50, 49, 60, 50, 91],
          },
          {
            name: "series-2",
            type: "bar",
            data: [20, 40, 35, 50, 49, 60, 20, 91],
          },
          {
            name: "series-3",
            type: "bar",
            data: [30, 40, 85, 50, 49, 60, 90, 91],
          },
          {
            name: "series-4",
            type: "bar",
            data: [30, 40, 35, 50, 49, 30, 70, 91],
          },
          ],
          }
          
        },
        methods:{
          async  getcandledata(sym){
             const response = await  getHistoricalData(sym)
             console.log(sym)
                  console.log(response)
                  const data = response.data
                  console.log(data)
                  const chart = response.data.chart
                  console.log(chart)
                  
                  // this.series=({
                  //   data : this.response.data.chart
                  // })
                  // console.log(this.series)
            }
        },
        mounted(){
          console.log(this.getcandledata('MSFT'))
          console.log(getHistoricalData('MSFT'))
        }
        
}
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
