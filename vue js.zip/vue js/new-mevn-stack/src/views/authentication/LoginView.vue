<template>
  <div>login
    <div>
      <form v-on:submit="onSubmit">
        <input type="text" placeholder="Username" v-model="username"/>
        <input type="text" placeholder="Password" v-model="password"/>
        <button type="submit">Submit</button>
      </form>
    </div>
  </div>
</template>

<script>
import * as auth from '../../services/AuthService'
export default {
  name: "login-view",
  data(){
    return{
      username:'',
      password:'',
    }
  },
  methods:{
    onSubmit(event){
        event.preventDefault()
        auth.login()
        this.$router.push({name : 'home'})
      console.log('submitted',this.username,this.password)  
    }
  }
};
</script>

<style></style>
