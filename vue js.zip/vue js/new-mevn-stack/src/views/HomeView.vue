<template>
  <div class="home">
    Home
    <router-link to="/tasks"><button>View Task</button></router-link>    
  </div>
</template>

<script>


export default {
  name: "HomeView",
  components: {
  },
  beforeEnter:(()=>{
    //get data from server
    //http.get()
  })
};
</script>

<style scoped>
.home{
    margin:50px;
    display:inline-block;
    padding:50px;
    border: 5px solid grey;
    border-radius: 20px;
    background-color: grey;
    box-sizing: border-box;
    box-shadow: 0px 0px 10px 10px rgb(236, 231, 231);
}
.home:hover{
  box-shadow: 10px 10px 10px 10px rgb(236, 231, 231);
  background-color: blueviolet;
}
button{
  display: grid;
  padding:15px;
  text-decoration: none;
}
</style>
