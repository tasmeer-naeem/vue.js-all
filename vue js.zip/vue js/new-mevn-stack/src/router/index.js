import { createRouter, createWebHistory } from "vue-router";
import HomeView from "../views/HomeView.vue";
import LoginView from "../views/authentication/LoginView.vue";
import RegisterView from "../views/authentication/RegisterView.vue";
import LogoutView from "../views/authentication/LogoutView.vue";
import TaskAll from "../views/task/TaskAll.vue";
import TaskCreate from "../views/task/TaskCreate.vue";
import TaskEdit from "../views/task/TaskEdit.vue";

const isLoggedIn = false
const routes = [
  {
    path: "/",
    name: "home",
    component: HomeView,
    beforeEnter  :  ((to,from,next)=>{
      if(isLoggedIn){
        next()
      }else{
        next('/login')
      }
  })
  },
  {
    path: "/login",
    name: "login-view",
    component: LoginView,
    beforeEnter  :  ((to,from,next)=>{
      if(!isLoggedIn){
        next()
      }else{
        next('/')
      }
  })
  },
  {
    path: "/register",
    name: "register-view",
    component: RegisterView,
    beforeEnter  :  ((to,from,next)=>{
      if(!isLoggedIn){
        next()
      }else{
        next('/')
      }
  })
  },
  {
    path: "/logout",
    name: "logout-view",
    component: LogoutView,
    beforeEnter  :  ((to,from,next)=>{
      if(isLoggedIn){
        next()
      }else{
        next('/login')
      }
  })
  },
  {
    path: "/tasks",
    name: "task-all",
    component: TaskAll,
    beforeEnter  :  ((to,from,next)=>{
        if(isLoggedIn){
          next()
        }else{
          next('/login')
        }
    })
  },
  {
    path: "/tasks/new",
    name: "task-create",
    component: TaskCreate,
    beforeEnter  :  ((to,from,next)=>{
      if(isLoggedIn){
        next()
      }else{
        next('/login')
      }
  })
  },
  {
    path: "/task/:id",
    name: "task-edit",
    component: TaskEdit,
    beforeEnter  :  ((to,from,next)=>{
      if(isLoggedIn){
        next()
      }else{
        next('/login')
      }
  })
  },
  // {
  //   path: "*",
  //   redirect: "/",
  // },
  {
    path: "/about",
    name: "about",
    // route level code-splitting
    // this generates a separate chunk (about.[hash].js) for this route
    // which is lazy-loaded when the route is visited.
    component: () =>
      import(/* webpackChunkName: "about" */ "../views/AboutView.vue"),
  },
  
];

// routes.beforeEach((to,from,next)=>{
//   if(isLoggedIn){
//     next()
//   }
//   else{
//     next('/login')
//   }
// })

const router = createRouter({
  history: createWebHistory(process.env.BASE_URL),
  routes,
  linkExactActiveClass:'active',
  linkActiveClass:'active',
  mode:history
});

export default router;
