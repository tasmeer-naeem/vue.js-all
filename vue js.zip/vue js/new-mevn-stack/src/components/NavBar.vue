<template>
    <div class="logo">
        <router-link to="/" class="navitem">MEVN</router-link>
    <div class="navbar">
        <router-link to="/" class="navitem " exact  >Home</router-link>
        <router-link to="/tasks" class="navitem " >Task</router-link>
        <router-link to="/login" class="navitem ">Login</router-link>
        <router-link to="/register" class="navitem ">Register</router-link>
        <router-link to="/logout" class="navitem ">Logout</router-link>
        <div class="navitem">username</div>
        <!-- <div class="navitem ">
            {{this.userName ? this.userName : 'user'}}
        </div> -->
    </div>
</div>
</template>

<script>
//import { mapState } from 'vuex';
export default {
   name : 'nav-bar',
   computed:{
    // ...mapState({
    //     userName:(state)=>state.userName
    // })
    // ...mapState(['userName'])
   },
   mounted(){
   // console.log('username',this.userName)
   }
}
</script>

<style scoped>
.logo{
    display: flex;
    justify-content: space-between;
    text-decoration: none;
    font-weight: 900;
}
.navbar{
    display:flex; 
}
.navitem{
    display: block;
    padding-right: 5vh;
    text-decoration: none;
    
}
.active{
     color:red   
}

</style>