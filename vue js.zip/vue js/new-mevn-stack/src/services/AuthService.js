import store from "@/store";

export function isLoggedIn(){
        const token = localStorage.getItem('token')
        return token != null
}

export function login(){
        const token = {
            username:'david'
        }
        setToken(token)
}

export function setToken(token){
        localStorage.setItem('token', JSON.stringify(token))
        store.dispatch('Authenticate')
}

export function getUserName(){
        return 'david'
}

export function getUserId(){
            return 1
}
