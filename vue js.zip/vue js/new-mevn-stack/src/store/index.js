import { createStore } from "vuex";
import * as auth from '../services/AuthService'

export default createStore({
  state: {
    isLoggedIn : false,
    apiURL : 'http//localhost:3000',
    userName: null,
    userId : null
  },
  getters: {},
  mutations: {
    Authenticate(state){
        state.isLoggedIn =  auth.isLoggedIn()
        if(state.isLoggedIn){
            state.userName = auth.getUserName()
            state.userId = auth.getUserId()
        }
        else{
          state.userName = null
          state.userId = null
        }
    }
  },
  actions: {
    Authenticate(context){
        context.commit('Authenticate')
    }
  },
  modules: {},
});
