// import express from "express";
// import morgan from "morgan";
// import cors from "cors";

const express = require('express')
const morgan = require('morgan')
const cors = require('cors')
const bodyparser = require('body-parser')

 function setEnv(app){
  //  console.log('setEnv env.js')
    if(process.env.NODE_ENV !== 'production'){
        setDevEnv(app)
    }
    else{
        setProdEnv(app)
    }
}

function setDevEnv(app){
    console.log('development environment env.js')
    app.use(bodyparser.json())
    app.use(morgan('dev'))
    app.use(cors)
}

function setProdEnv(app){
    app.use(bodyparser.json())
    app.use(express.static(__dirname + '/../dist'))
    console.log('production environment env.js')
}

module.exports={setEnv}
