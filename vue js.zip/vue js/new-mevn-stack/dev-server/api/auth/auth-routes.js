//import express from 'express'
const express = require('express')
const router = express.Router()

router.post('/auth',(req,res)=>{
    res.send('post.auth - login a user')
})

module.exports=router
