//import express from 'express'
const express = require('express')
const router = express.Router()

router.post('/task',(req,res)=>{
    res.send('post.task create a task')
})
router.get('/task',(req,res)=>{
    res.send('getall.task get all task')
})
router.get('/task/:id',(req,res)=>{
    res.send('get.task get a task by id')
})
router.put('/task',(req,res)=>{
    res.send('update.task update a task')
})
router.delete('/task',(req,res)=>{
    res.send('delete.task delete a task')
})

module.exports=router
