//import express from 'express'
const express = require('express')
const router = express.Router()


router.get('/user',(req,res)=>{
    res.send('getall.user get all users')
})
module.exports=router
