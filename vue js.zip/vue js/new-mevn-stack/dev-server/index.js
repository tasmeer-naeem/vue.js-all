///// expree js ////////
//import express from 'express'
//const app = express()
//import {registerAllRoutes} from './routes'
//import { setEnv } from './config/env'

const express = require('express')
const app = express()
const {registerAllRoutes} = require('./routes')
const {setEnv} = require('./config/env')
const e = require('express')
const port = 3000

setEnv(app)
registerAllRoutes(app)

app.get('/', (req, res) => {
 // res.send('Hello World!')
 if(process.env.NODE_ENV !== 'production'){
  return res.send('development mode')
 }
 else{
 // console.log('else')
  return res.sendFile('index.HTML' , {root : __dirname + '/../dist'})
 }
})

app.listen(port, () => {
  console.log(`dev-server app listening on port ${port}` + process.env.NODE_ENV + 'mode')
})

////// node js ///////
// const http = require('http');

// const hostname = '127.0.0.1';
// const port = 3000;

// const server = http.createServer((req, res) => {
//   res.statusCode = 200;
//   res.setHeader('Content-Type', 'text/plain');
//   res.end('Hello World');
// });

// server.listen(port, hostname, () => {
//   console.log(`Server running at http://${hostname}:${port}/`);
// });