
// import taskRoutes from './api/task/task-routes'
// import authRoutes from './api/auth/auth-routes' //login-route
// import registerRoutes from './api/register/register-routes'
// import userRoutes from './api/user/user-routes'

const taskRoutes = require('./api/task/task-routes')
const authRoutes = require('./api/auth/auth-routes') 
const registerRoutes = require('./api/register/register-routes')
const userRoutes = require('./api/user/user-routes')

  function registerAllRoutes(app){
  //  console.log('registerAllRoutes')
    app.use('/api',taskRoutes)
   app.use('/api',authRoutes)
   app.use('/api',registerRoutes)
   app.use('/api',userRoutes)
} 

module.exports = {registerAllRoutes}