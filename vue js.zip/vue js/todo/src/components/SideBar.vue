<template>
  <div>
sidebar
  </div>
</template>

<script>
export default {
    name : "SideBar"
}
</script>

<style>

</style>