<template>
  <div>
navbar
  </div>
</template>

<script>
export default {
        name : "NavBar"
}
</script>

<style>

</style>