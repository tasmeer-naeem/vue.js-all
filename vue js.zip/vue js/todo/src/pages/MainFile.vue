<template>
  <div>
  main
  </div>
</template>

<script>
export default {
        name : "MainFile"
}
</script>

<style>

</style>