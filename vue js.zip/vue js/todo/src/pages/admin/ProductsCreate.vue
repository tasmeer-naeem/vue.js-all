<template>
  <div>
ProductsCreate
  </div>
</template>

<script>
export default {
        name : "ProductsCreate"
}
</script>

<style>

</style>