<template>
  <div>
    Admin
    <nav-bar/>
    <side-bar/>
  </div>
</template>

<script>


import NavBar from '@/components/NavBar.vue'
import SideBar from '@/components/SideBar.vue'

export default {
        name : "AdminDashboard",
         components: {
      NavBar,
      SideBar
  }
}
</script>

<style>

</style>