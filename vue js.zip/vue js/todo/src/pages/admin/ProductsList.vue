<template>
  <div>
ProductsList

  </div>
</template>

<script>
export default {
        name : "ProductsList"
}
</script>

<style>

</style>