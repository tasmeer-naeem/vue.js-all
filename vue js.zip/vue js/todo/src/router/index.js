import {createRouter , createWebHistory } from 'vue-router'
import AdminDashboard from '../pages/admin/AdminDashboard.vue'
import ProductsList from '../pages/admin/ProductsList.vue'
import ProductsCreate from '../pages/admin/ProductsCreate.vue'
import ProductsEdit from '../pages/admin/ProductsEdit.vue'
import MainFile from '../pages/MainFile.vue'

const Routes = [
    {
        path : "/",
        name : "MainFile",
        component : MainFile
    },
    {
        path : "/admin",
        name : "AdminDashboard",
        component : AdminDashboard,
        children : [
            {
                path : "products",
                name : "ProductsList",
                component : ProductsList
            },
            {
                path : "products/create",
                name : "ProductsCreate",
                component : ProductsCreate
            },
            {
                path : "products/:id/edit",
                name : "ProductsEdit",
                component : ProductsEdit,
                props : true
            }
        ]
    }
    
]

const Router = createRouter({
    history: createWebHistory(process.env.BASE_URL),
    Routes
  })

export default Router;