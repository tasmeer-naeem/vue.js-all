import SignUp from './components/SignUp'
import HomeFile from './components/HomeFile'
import LoginFile from './components/LoginFile'
import AddFile from './components/AddFile'
import UpdateFile from './components/UpdateFile'
import { createRouter , createWebHistory } from 'vue-router'

const routes=[
    {
        name : "SignUp",
        component : SignUp,
        path : "/signup"
    },
    {
        name : "HomeFile",
        component : HomeFile,
        path : "/"
    },
    {
        name : "LoginFile",
        component : LoginFile,
        path : "/login"
    },
    {
        name : "AddFile",
        component : AddFile,
        path : "/add"
    },
    {
        name : "UpdateFile",
        component : UpdateFile,
        path : "/update/:id"
    }
]

const router = createRouter({
    history : createWebHistory(),
    routes
})

export default router