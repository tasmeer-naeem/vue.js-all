<template>
  <div style="font-size : 30px">
    
      <router-link to="/">Home </router-link >
       <router-link  to="/add">Add </router-link >
        <a href="#" v-on:click="logout"  >Logout </a>

  </div>
</template>

<script>
export default {
name : "HeaderFile",

methods:{
    logout(){
       // console.log('logout')
       localStorage.clear()
       this.$router.push({name:"SignUp"})
    }
}
}
</script>

<style>

div{
  font-family: 'Times New Roman', Times, serif;
  font-weight: bold;
  letter-spacing: 1px;
  word-spacing: 20px;
}

</style>