<template>
  <div>
      Update
      <header-file/>
       <input type="text" name="name" placeholder="Enter Name" v-model="restaurant.name"/>
       <input type="text" name="contact" placeholder="Enter Contact" v-model="restaurant.contact"/>
       <button type="button" v-on:click="updatedata" >Update</button>
  </div>
</template>

<script>
import axios from 'axios'
import HeaderFile from './HeaderFile.vue'
export default {
  components: { HeaderFile },
name : "UpdateFile",
data(){
return{
    restaurant:{
            name:'',
            contact:''

    }
}
},
methods:{
    async updatedata(){
       // console.log(this.restaurant)
    const result = await axios.put("http://localhost:3000/restaurant/"+this.$route.params.id,{
           name : this.restaurant.name,
           contact : this.restaurant.contact,
        })
       // console.log(result)
       if(result.status == 200 ){
            this.$router.push({name : "HomeFile"})
            }
     }
},
 async mounted(){
              let user = localStorage.getItem("user-info")
              if(!user){
                this.$router.push({name : "SignUp"})
              }
              //console.log(this.$route.params.id)
              const result = await axios.get("http://localhost:3000/restaurant/"+this.$route.params.id)
             // console.log(result)
             this.restaurant.name=result.data.name
             this.restaurant.contact=result.data.contact
        },
}
</script>

<style>

</style>