<template>
  <div class="table">
      Account - {{this.name}}
      <header-file/>
      <table border="2" >
        <tr style="font-weight : bold">
          <td>Id</td>
           <td>Name</td>
            <td>Contact</td>
            <td colspan="2">Actions</td>
        </tr>
        <tr v-for="item in restaurant" :key="item.id"  >
          <td >{{item.id}}</td>
          <td>{{item.name}}</td>
          <td>{{item.contact}}</td>
          <td><router-link  :to="'/update/'+item.id">Update</router-link></td>
          <td><button v-on:click="deleteitem(item.id)" >Delete</button></td>
        </tr>
      </table>
  </div>
</template>

<script>
import axios from 'axios'
import HeaderFile from './HeaderFile.vue'
export default {
  components: { HeaderFile },
name : "HomeFile",

data(){
return{
  name:'',
  restaurant:[]
}
},
methods:{
      async deleteitem(id){
        //console.log(id)
        let result = await axios.delete("http://localhost:3000/restaurant/"+id)
        console.log(result)
        if(result.status === 200){
          this.loaddata()
        }
      },

      async loaddata(){
          let user = localStorage.getItem("user-info")
                this.name=JSON.parse(user).name
              if(!user){
                this.$router.push({name : "SignUp"})
              }
              let result = await  axios.get("http://localhost:3000/restaurant")
              //console.log(result)
              this.restaurant=result.data;
      }
},
  mounted(){
             this.loaddata()
        },
}
</script>

<style>



tr td{
  width: 150px;
  height:20px
}
</style>