<template>
  <div class="login">
      Login
    <img class="logo" src=""/>
  <div class="login">
       <input type="text" v-model="email" placeholder="Enter Email"/>
        <input type="password" v-model="password" placeholder="Enter Password"/>
        <button v-on:click='login()' >Login</button>
         <h3><router-link to="/signup" >Sign Up</router-link>  </h3>
  </div>
  </div>
</template>

<script>

import axios from 'axios'
export default {
        name : 'LoginFile',

        data(){
          return{
            email:'',
            password:''
          }
        },

        methods:{
          async login(){
           // console.log('clicked',this.email,this.password)

          let result =  await axios.get(`http://localhost:3000/users?email=${this.email}&password=${this.password}`)
           // console.log(result)
           if(result.status == 200 && result.data.length>0){
              //alert("sign-up done")
            localStorage.setItem("user-info",JSON.stringify(result.data[0]))
            this.$router.push({name : "HomeFile"})
            }
        },

        },

 mounted(){
              let user = localStorage.getItem("user-info")
              if(user){
                this.$router.push({name : "HomeFile"})
              }
        },

}
</script>

<style>

.login{
  display: inline-flex;
  flex-direction: column;
}

</style>