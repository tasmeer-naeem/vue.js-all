<template>
  <div class="register">
      Sign up
    <img class="logo" src=""/>
  <div class="register">
      <input type="text"  v-model="name" placeholder="Enter Name"/>
       <input type="text" v-model="email" placeholder="Enter Email"/>
        <input type="password" v-model="password" placeholder="Enter Password"/>
        <button v-on:click='signup()' >Sign Up</button>
        <h3><router-link to="/login" >Login</router-link>  </h3>
  </div>
  </div>
</template>

<script>
import axios from 'axios'

export default {
        name : 'SignUp',

        data(){
          return{
            name:'',
            email:'',
            password:''
          }
        },

        methods:{
          async signup(){
            //console.log('clicked',this.name,this.email,this.password)

            let result = await axios.post("http://localhost:3000/users",{     //axios.post
              name : this.name,
              email : this.email,
              password : this.password
            })
            console.log(result)
            if(result.status == 201){
              //alert("sign-up done")
            localStorage.setItem("user-info",JSON.stringify(result.data))
            this.$router.push({name : "HomeFile"})
            }
          }
        },

        mounted(){
              let user = localStorage.getItem("user-info")
              if(user){
                this.$router.push({name : "HomeFile"})
              }
        },


}
</script>

<style>

.register{
  display: inline-flex;
  flex-direction: column;
}

input{
    padding: 4px;
    width: 250px;
}

button{
  margin: 4px;
}

</style>