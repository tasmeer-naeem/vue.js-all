<template>
  <div class="add">
      Add
      <header-file/>
      <input type="text" name="name" placeholder="Enter Name" v-model="restaurant.name"/>
       <input type="text" name="contact" placeholder="Enter Contact" v-model="restaurant.contact"/>
       <button type="button" v-on:click="adddata" >Add</button>
  </div>
</template>

<script>
import axios from 'axios'
import HeaderFile from './HeaderFile.vue'

export default {
  components: { HeaderFile },
name : "AddFile",

data(){
return{
    restaurant:{
            name:'',
            contact:''

    }
}
},
methods:{
    async adddata(){
        //console.log(this.restaurant)
        const result = await axios.post("http://localhost:3000/restaurant",{
           name : this.restaurant.name,
           contact : this.restaurant.contact,
        })
       // console.log(result)
        if(result.status == 201){
           this.$router.push({name : "HomeFile"})
        }
    }
},

 mounted(){
              let user = localStorage.getItem("user-info")
              if(!user){
                this.$router.push({name : "SignUp"})
              }
        },
}
</script>

<style>



</style>