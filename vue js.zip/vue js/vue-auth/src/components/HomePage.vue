<template>
  <div class="home">
    <h2>home</h2>
   
  </div>
</template>

<script>
export default {
  name: 'HomePage',
  props: {
  
  }
}
</script>

<style >
.home{
  display: flex;
  flex-direction: row;
  justify-content: space-evenly
}
</style>
