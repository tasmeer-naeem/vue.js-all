<template>
  <div class="home">
    <h2>home</h2>
    <h3>login</h3>
    <h3>sign up</h3>
  </div>
</template>

<script>
export default {
  name: 'NavBar',
  props: {
  
  }
}
</script>

<style >
.home{
  display: flex;
  flex-direction: row;
  justify-content: space-evenly
}
</style>
