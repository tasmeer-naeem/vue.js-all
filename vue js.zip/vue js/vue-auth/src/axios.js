import axios from 'axios'

axios.defaults.baseURL = 'http://localhost:3000/'