<template>
  <div>
    loadingg
    <!-- <vue-progress-bar></vue-progress-bar> -->
     <!-- <vue3-progress-bar /> -->
       <vue3-progress />
  </div>
</template>

<script>

export default {
        name:"LoadingLine",
         created() {
            setTimeout(() => {
                 this.$progress.start();
            }, 1000);
          },
          mounted(){
              setTimeout(() => {
                 this.$progress.finish();
            }, 9000);
          }
        
}
</script>

<style>

</style>