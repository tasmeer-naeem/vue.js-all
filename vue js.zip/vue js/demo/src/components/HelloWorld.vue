

<template>
  <div class=" text-info">
    {{this.arrProp}}
    <p v-bind:title="title" v-bind:class="{active : isActive}" :style="asdf" >{{message}}</p>

    <div> {{toggle ? imagee : 'click btn'}}   </div>
    <button @click="toggleFunc"> toggle1 </button>

    <div v-if="toggle"> toggle true </div>
    <div v-if="!toggle"> toggle false </div>
 <button @click="toggle = !toggle "> toggle2 </button>

<!-- <img src='../assets/logo.png'  v-if="toggle"/> -->
 <button @click="toggleFunc2"> toggle3 </button>

     <div> props {{ opacityProp }}  -  {{arrProp}}</div>

    <button @click="showtab1func()">tab 1 </button>
     <button @click="showtab2func()">tab 2   </button>
      <button @click="showtab3func()">tab 3 </button>

    <div v-if="showTab1">1st tab </div>
    <div v-if="showTab2">2nd tab 
      <pop-up modalHeader='tab 2 ------'/>
      <modal-view modalHeader='tab 2 ------'/>
    </div>
    <div v-if="showTab3">3rd tab 
    <modal-view  v-show='showTab3'  @close="closeModal" :proptext="text" :proptitle="title" modalHeader='tab 3 ----'/>
    </div>

   

  </div>
</template>

<script>
//import logo from '../assets/logo.png'
import PopUp from './PopUp.vue'
import ModalView from './ModalView.vue'
export default {
  components: { PopUp, ModalView },
  name: 'HelloWorld',


  props: {
    opacityProp : String ,
    arrProp : Array
  },

  data(){
    return{
      text:"texthelloworld",
      title:"titlehelloworld",
      message : 'v-bind testing',
      titlee : 'v-bind title',
      asdf: 'background-color : red ; display : inline-block',
      imagee: '../assets/logo.png',
      toggle : false,
      showTab1 : true,
      showTab2 : false,
      showTab3 : false,
      closeTab : true
    }
  },
  methods:{
    toggleFunc(){
      this.toggle = true
    },
    toggleFunc2(){
        this.toggle = !this.toggle
    },
    showtab1func(){

     // console.log(props)

      this.showTab1 = true,
      this.showTab2 = false
      this.showTab3 = false
      
    },
     showtab2func(){
      this.showTab1 = false,
      this.showTab2 = true
      this.showTab3 = false
    },
     showtab3func(){
      this.showTab1 = false,
      this.showTab2 = false
      this.showTab3 = true
    },
    closeModal(){
      this.showTab3 = false
    }

  
  },

  mounted(){
    setInterval(function () 
    {console.log("seconds ago")}
    , 1000); 

   
      console.log(this.arrProp)
    
  },

  created () {
   // console.log(this.opacityProp)
  }
}

</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
h3 {
  margin: 40px 0 0;
}
ul {
  list-style-type: none;
  padding: 0;
}
li {
  display: inline-block;
  margin: 0 10px;
}
a {
  color: #42b983;
}
</style>
