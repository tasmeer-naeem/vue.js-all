<template>
  
  <div class="">
      demo
     <folder-tree/>
      <tree-view/>
      <loading-line/>
      <hello-world :opacityProp = "opacity"  :arrProp="arr" />
      <video-file/>
      <time-ago/>
      <modal-view :textprop='text' :titleprop='title' modalHeader="demoFileModalHeader"/>
      
  </div>
</template>

<script>
import HelloWorld from './HelloWorld.vue'
import TimeAgo from './TimeAgo.vue'
import VideoFile from './VideoFile.vue'
import ModalView from './ModalView.vue'
import LoadingLine from './LoadingLine.vue'
import TreeView from './TreeView.vue'
import FolderTree from './FolderTree.vue'

export default {
  components: { HelloWorld, VideoFile, TimeAgo, ModalView, LoadingLine, TreeView, FolderTree },
    name : 'DemoFile',


    data() {
        return{
        text:"textdemofile",
        title:"titledemofile",
        opacity : 'opacity-data-variable',
        arr : ['a','b','c'],
        }
    },
   

}
</script>

<style>

</style>