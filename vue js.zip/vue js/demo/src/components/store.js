import {createStore} from 'vuex'

export default createStore({

    state:{
        name:'vue-store state variable',
        id : 123,
        cell : 111,
        age : 22
    },
    mutations:{
        newValueFunc(state,payload){    //state : defined value  , payload : new value to be set
            state.name = payload.newValue   // newValue var is coming from VideoFile methods
        }
    },
    actions:{
        // setNewValue(context,payload){     //context.commit is used to call mutation function
        //     setTimeout(() => {
        //         context.commit('newValueFunc',payload) //payload is new value to be set coming from another file 
        //     }, 1000);}

        setNewValue(context,payload){
            return new Promise((resolve)=>{
                setTimeout(() => {
                    context.commit('newValueFunc',payload) 
                    resolve("resolved")
                }, 1000);
            })        
        },

        setNewValue2(context){
          context.dispatch({type : 'setNewValue' , newValue : 'new value'}).then((Response)=>{
              console.log('promise',Response)
          })
        }
    },
    getters:{
        hasAdd(state){            // getter functions always use return 
            return  state.id + '##'
        },

        hasNewAdd(state,getters){          //getters. is used to call getter function
            return state.cell + ' - ' + getters.hasAdd
        },

       // ageVar:(state)=> state.age
        ageVar:(state)=>(data)=> state.age + ' -- ' + data
    }
})
