<template>
  <div class="container">    
      <time-ago class="title" refresh :locale="locale" :long="longString" />
  
    <div class="timeago">
      <time-ago
        :datetime="value"
        refresh
        :locale="locale"
        :tooltip="tooltip"
        :long="longString"
      />
    </div>
   
  </div>
</template>

<script>
import { TimeAgo } from "vue2-timeago";
//import "vue2-timeago/dist/vue2-timeago.css";


export default {
  components: {
   
    TimeAgo,
  },
  data() {
    return {
      value: new Date(),
     
      }
  },
  methods: {
    timeRefresh({ timeago, nowString, timestamp }) {
      console.log(timeago);
      console.log(nowString);
      console.log(timestamp);
    },
    
  },
};
</script>

<style>
.container {
  font-family: "Roboto Slab", serif;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  padding: 10px;
  height: 500px;
}
.timeago {
  margin-top: 50px;
  border: 2px solid #47b784;
  padding: 10px;
}
.timeago span {
  font-size: 15px;
}
.box {
  margin: 20px;
}
</style>