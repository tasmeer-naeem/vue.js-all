<template>
  <div :style="customStyle" >
      VideoFile
      <p :class="Status ? 'class1' : 'class2'">{{$store.state.name}} OR  {{nameVar}} ID {{idVar}}</p>   
      <button v-on:click='handleClick()' >change</button>
      <button v-on:click="handleClick2({ newValue : 'new mutation value'  })">change2</button>
      <p>{{callGetter}} - {{ageGet('23')}}</p>
  </div>
</template>

<script>
import {mapActions, mapGetters, mapMutations, mapState} from 'vuex'
export default {
        name : 'VideoFile',
     data(){
      return{
          isError : 'error',
          isSuccess : 'success',
          Status : false,  
      }
     },
        methods:{
          ...mapActions({
            handleClick : 'setNewValue2'
          }),
          ...mapMutations({
              handleClick2 : 'newValueFunc'
          }),
         //   handleClick(){
              /// mutation function ////
           //   this.$store.state.name='new value'
            //  this.$store.commit('newValueFunc','new value')     //func name , new payload val pass to store
            // this.$store.commit({type : 'newValueFunc' , newValue : 'new value'})

              /// action function ///
              //this.$store.dispatch({type : 'setNewValue', newValue :'new value'})

              // this.$store.dispatch({
              //   type : 'setNewValue', newValue :'new value'}).then((Response)=>{
              //     console.log('promise',Response)
              //   })}   

            //  this.$store.dispatch('setNewValue2')
           // }    
        },
        computed:{
          ...mapState({
                nameVar:(state)=>state.name,
                idVar:(state)=>state.id
          }),
          ...mapGetters({
            callGetter : 'hasNewAdd',
            ageGet : 'ageVar'
          }),

          customStyle(){
            return "color:red ; background-color:lightblue"
          },

       
            //// getter function ////
            // callGetter(){
            //   return this.$store.getters.hasNewAdd   //hasAdd
            // },

            // ageGet(){
            //   return this.$store.getters.ageVar('23')
            // }
        },
        watchers:{

        },
        
}
</script>

<style>
.class1{
  color : white
}
.class2{
  color : green
}
</style>