<template>
<div>
  <div v-for="item in popupheaderprop" :key="item">
    {{item}}
      Pop up 
  </div>
  </div>
</template>

<script>
export default {
        name : "PopUp",

        props:{
          popupheaderprop:{
            type:Array,
            default:()=>{}
          }
        },
        mounted(){
          console.log('popupheaderprop',this.popupheaderprop)
        }
}
</script>

<style>

</style>