<template>
  <div  :modalHeader="modalHeader" >{{showTab3}} - {{closeTab}} 
  <div>- {{proptext}} - {{proptitle}}</div>
  <div> modal == {{modalHeader}}</div> 
      <button @click="closeModalfunc()"  >close</button>
      <!-- <button @click="showTab3 = !showTab3">close</button> -->
      <pop-up :popupheaderprop='popupheader'/>
  </div>
</template>

<script>
import PopUp from './PopUp.vue'
export default {
  components: { PopUp },
            name:"ModalView",
            modal:true,

            data(){
              return{
                  popupheader:['popupheader','popupheader2']
              }
            },

            props:{
              modalHeader : {
                type :String,
                default : "Modal Header"
              },
              proptext : String,
              proptitle : String
              //  showTab3 : Boolean,
              //  closeTab : Boolean
            },

            methods:{
                closeModalfunc(){
                  //  console.log(this.props)
                    this.$emit("close")
                  //  this.props.showTab3 = true
                  //  this.props.closeTab = false
                   // this.modal = false
                   //  this.props.showTab3 = !this.props.showTab3
                },

            mounted(){
                console.log(this.showTab3)  //(this.props)
            }
            }
}
</script>

<style>

</style>