<template>
  <div>
    folder structureeeee
   <v-folder :data="data" :ajax="ajax" :conf="conf" @change="onChange"></v-folder>
  </div>
</template>

<script>
import VFolder from 'v-folder';
export default {
            name:'FolderTree',
            compoenets:{
                    VFolder
            },
   data() {
    return {
      uid: 0,
      conf: {
        // tree node name
        node: 'sourceDir',
        // KEY NAME of dirs/branches/parents etc.. .
        branch: 'dirs',
        // KEY NAME of  files/leafs/children etc...
        leaf: 'files'
      },
      data: {
        // root
        sourceDir: 'Root',
        // children
        files: ['file1','file2','file3'],
        dirs: ['folder1','folder2','folder3']
      },
      // ajax settings
      ajax: {
        method: 'GET',
        url: 'http://localhost:1234',
        params: {},
        data: {},
        headers: {},
        // params key of path
        pathAs: 'path',
        // process response data
        process: (res) => res.data
      }
    };
  },
  methods: {
    onChange(result) {
      console.log('result',result);
    }
  }
}
</script>

<style>

</style>