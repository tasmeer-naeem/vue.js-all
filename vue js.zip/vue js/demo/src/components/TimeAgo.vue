<template>
  <div>
      TimeAgo

    
    <button @click='increament' >increament</button>
    <p>count  {{count}} </p>
    <button @click='decreament' >decreament</button>
    <div id='time' >{{datatime}}

  </div>
    
  </div>
</template>

<script>

import moment from 'moment'
import TimeAgo from 'javascript-time-ago'
import en from 'javascript-time-ago/locale/en.json'
TimeAgo.addDefaultLocale(en)
const timeAgo = new TimeAgo('en-US')
//timeAgo.format(new Date())
//const t = timeAgo.format(Date.now(), 'round')
const t = timeAgo.format(Date.now(), 'round')
//setInterval(t,1000)
console.log(t)

//const time=new Date()
const date= moment().fromNow()
console.log(date)

var m2 = new Date()
var m1 = moment(m2)
console.log(m1.fromNow())


var timestamp = "05/11/2022 15:00:00 AM";            //new Date()      //"05/11/2022 10:00:00 AM";
//var LastReading = moment(timestamp).fromNow();
var LastReading = moment(timestamp, "MM/DD/YYYY hh:mm:ss A ").fromNow();
console.log(LastReading)

var now = moment(new Date());
console.log(now)

console.log(moment([]))



var sec = new Date
console.log(sec.getHours()+ ' '+sec.getMinutes()+ ' '+sec.getSeconds())

document.getElementById("time")

//console.log(moment().toNow())

// function doDate()
// {
//     var str = "";

//     var days = new Array("Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday");
//     var months = new Array("January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December");

//     var now = new Date();

//     str += "Today is: " + days[now.getDay()] + ", " + now.getDate() + " " + months[now.getMonth()] + " " + now.getFullYear() + " " + now.getHours() +":" + now.getMinutes() + ":" + now.getSeconds();
//    // document.getElementById("todaysDate").innerHTML = str;
//     console.log(str)
//     var z=moment(str).fromNow()
//     console.log(z)
// }

// setInterval(doDate, 1000);

  // function dt(){
      // let d = new Date()
       //console.log(d)
      // let t = moment("14:00:00 05/11/2022").fromNow()

      // var hh = d.getHours
      // var mm = d.getMinutes
      // var ss = d.getSeconds
      // var dd = d.getDay
      // var m = d.getMonth
      // var yyyy = d.getFullYear
       // let t = moment(hh,mm,ss, dd,m,yyyy).fromNow()

      // console.log(t)
 //  }
  // setInterval(dt,1000)

// From 2.12.0 onward

const m = moment()

moment.updateLocale('en', {
    relativeTime : Object
});
// From 2.8.1 to 2.11.2
moment.locale('en', {
    relativeTime : Object
});

// Deprecated in 2.8.1
moment.lang('en', {
    relativeTime : Object
});

 moment.updateLocale('en', {
    relativeTime : {
        future: "in %s",
        past:   "%s ago",
        s  : 'a few seconds',
        ss : '%d seconds',
        m:  "a minute",
        mm: "%d minutes",
        h:  "an hour",
        hh: "%d hours",
        d:  "a day",
        dd: "%d days",
        w:  "a week",
        ww: "%d weeks",
        M:  "a month",
        MM: "%d months",
        y:  "a year",
        yy: "%d years"
    }
});
console.log(m)

        function dateTime(){
         let a = this.count ++
          console.log(a)
        }
        console.log(dateTime)

//console.log(moment.duration(4,'weeks').days())
//console.log(moment.duration(4,'weeks').get('days'))

console.log(moment().toString())

export default {
        name :'TimeAgo',

        data(){
          return{
          count : 0,
          thenn : '11:00 5/12/2022',
            noww : '11:35 5/12/2022',
            a : moment([2022, 0, 29]),
             b : moment([2022, 0, 28])
          }
        },


        computed:{
            datatime(){
              return this.a.diff(this.b)        //this.thenn - this.noww
            }

        },
        

      methods:{
       increament(){
         this.count++
       },
        decreament(){
         this.count--
       }

      },
      

        
}
</script>

<style>

</style>