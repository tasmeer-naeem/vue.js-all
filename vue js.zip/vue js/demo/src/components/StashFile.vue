<template>
  <div>
    stash file
  </div>
</template>

<script>
export default {
        name:'StashFile'
}
</script>

<style>

</style>