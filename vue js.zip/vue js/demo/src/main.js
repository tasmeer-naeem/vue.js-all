import { createApp } from 'vue'
import App from './App.vue'
import store from './components/store'
//import VueProgressBar from "@aacassandra/vue3-progressbar";
//import Vue3ProgressBar from "vue3-progress-bar";
import Vue3Progress from "vue3-progress";




  // in your vue instance
 
const options = {
    position: "fixed",
    height: "10px",
    color: "red",
  };

// const options = {
//     color: "#bffaf3",
//     failedColor: "#874b4b",
//     thickness: "5px",
//     transition: {
//       speed: "0.2s",
//       opacity: "0.6s",
//       termination: 300,
//     },
//     autoRevert: true,
//     location: "left",
//     inverse: false,
//   };

const app = createApp(App)

app.use(store)
//app.use(VueProgressBar, options)
app.use(Vue3Progress, options)
//app.use(Vue3ProgressBar, options)
app.mount('#app')

