<template>
<div>

  <demo-file/>
</div>
</template>

<script>

import DemoFile from './components/DemoFile.vue'
//import HelloWorld from './components/HelloWorld.vue'

export default {
  name: 'App',
  components: {
   // HelloWorld,
    DemoFile
  }
}

//  <img alt="Vue logo" src="./assets/logo.png">
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}

</style>

