<template>
  <div>
     {{todo.title}}
        <button>Edit</button>
        <button>Delete</button>
  </div>
</template>

<script>

export default {
    name : "TodoItem",
    props:{
        todo : {}
    }
}
</script>

<style>

</style>