<template>
  <div>
     <input    v-bind:value="TodoText" @change="TodoChangeText" type="text" />   
     <button @click="AddTodo()" >Add</button>
  </div>
</template>


<script>


import { mapActions } from "vuex";
import { v1 } from 'uuid';

export default {
    data(){
        return{
            TodoText:""
        }
    },
  methods:{
      ...mapActions(['addTodo']),

      TodoChangeText(e){
          this.TodoText = e.target.value
      },

      AddTodo(){
          this.addTodo({
               id : v1(),
              title : this.TodoText,
          }),
          this.TodoText=''
      }
  }
}

////v-model="TodoText"

</script>

<style>

</style>