// import vue, { VueElement } from 'vue'
// import vuex from 'vuex'
import createStore from 'vuex'

//VueElement.arguments(vuex)

//vue.use(vuex)
//export default new Vuex.Store({

//export default new vuex.Store({
export default createStore({
    state:{
        todos :[ 
            {id : 1 , title : "one"},
            {id : 2 , title : "two"},
        ]
    },  
    getters : {
        allTodos : (state)=> state.todos,
    },
    actions:{
        addTodo({commit},todo){
            commit("add_todo",todo)
        }
    },
    mutations:{
        add_todo(state,todo){
            state.todos.push(todo)
            console.log(todo)
        }
    },
    modules:{

    }
})