<template>
  <div>logout</div>
</template>

<script>
export default {
  name: "logout-view",
};
</script>

<style></style>
