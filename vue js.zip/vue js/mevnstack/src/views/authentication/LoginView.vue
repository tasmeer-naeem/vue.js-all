<template>
  <div>login</div>
</template>

<script>
export default {
  name: "login-view",
};
</script>

<style></style>
