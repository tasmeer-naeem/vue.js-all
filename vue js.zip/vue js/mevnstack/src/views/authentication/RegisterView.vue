<template>
  <div>register</div>
</template>

<script>
export default {
  name: "register-view",
};
</script>

<style></style>
