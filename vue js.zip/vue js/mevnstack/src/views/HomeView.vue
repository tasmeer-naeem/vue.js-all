<template>
  <div class="home">
    Home
    <!-- <NavBarVue />
    <router-view></router-view> -->
    <!-- <img alt="Vue logo" src="../assets/logo.png" />
    <HelloWorld msg="Welcome to Your Vue.js App" /> -->
  </div>
</template>

<script>
// @ is an alias to /src
//import HelloWorld from "@/components/HelloWorld.vue";
//import NavBarVue from "@/components/NavBar.vue";
export default {
  name: "HomeView",
  components: {
   // NavBarVue,
    //  HelloWorld,
  },
};
</script>
