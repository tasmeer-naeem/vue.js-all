<template>
  <div>taskcreate</div>
</template>

<script>
export default {
  name: "task-create",
};
</script>

<style></style>
