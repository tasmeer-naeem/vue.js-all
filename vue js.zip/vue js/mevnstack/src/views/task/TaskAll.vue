<template>
  <div>task</div>
</template>

<script>
export default {
  name: "task-all",
};
</script>

<style></style>
