<template>
  <div>taskedit</div>
</template>

<script>
export default {
  name: "task-edit",
};
</script>

<style></style>
