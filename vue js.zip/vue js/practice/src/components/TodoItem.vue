<template>
  <div class="todoItem">
      <ul v-for='item in items' :key="item.id">
          <li>
          {{item}}
          </li>
          <!-- <li>item 1</li>
          <li>item 2</li>
          <li>item 3</li> -->
      </ul>
  </div>
</template>

<script>
export default {
        name: "TodoItem",

        data(){
            return{
                items : ['item-1','item-2','item-3','item-4']
            }
        }
}
</script>

<style scoped>
.todoItem{
    display: inline-block;
}
</style>