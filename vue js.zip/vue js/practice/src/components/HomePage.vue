<template>
  <div class="home">

    {{count}}
      <todo-input/>
  </div>
</template>

<script>
import moment from 'moment'
import TodoInput from './TodoInput.vue'
export default {
    name : "HomePage",
  components: { TodoInput },
  data(){
    return{
      count:0,
      then:moment(),
    }    
  },

  methods:{
        timeAgo(){
          let now = moment();
          let seconds =  now.diff(this.then, 'seconds')
          let minutes = now.diff(this.then,'minutes')
          let hours = now.diff(this.then , 'hours')
           if(seconds < 10){                                  //60
               this.count =  seconds + ' seconds ago'  
            }
             if(seconds >= 10){
               this.count =  minutes + ' minutes ago'  
            }
             if(minutes >= 5){
               this.count =  hours + ' hours ago'  
            }
        }
  },

  mounted(){
    setInterval(() => {
     // this.count ++
     this.timeAgo()
    }, 1000);
  }

}
</script>

<style>
.home{
    display: inline-grid;
}
</style>