<template>
  <div class="TodoList">
    todo list
  
  </div>
</template>

<script>

export default {
        name: "TodoList",
        components: { 
                        
        },
}
</script>

<style>

</style>