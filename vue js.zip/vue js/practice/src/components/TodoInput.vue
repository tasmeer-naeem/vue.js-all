<template>
<!--  utube webcodecamp     -->
<!--  utube leela web dev  (watch later)    -->

  <div class="TodoInput">
      <form v-on:submit="HandleSubmit" class="">
      <input  type="text"  v-model="name" placeholder="add" />
      <button :disabled='isDisabled == false' >Add</button>
      </form>
      <br/>
        <button @click="UpdatedItem" :disabled='isDisabled' >Update</button>
       <!-- {{name}} -->
       <br/><br/>
       <select class="select">
           <option selected >-- none -- </option>
           <option v-for="(item,index) in searchFunc" :key="index"  >
               {{item.name}}
           </option>
       </select>
       <br/><br/>
      <input type="text" v-model="search" placeholder="search" name="query" /> 
    <span  v-if="!searchFunc.length" :style="this.highlight"  >  no results found</span>
      <br/><br/>
      <button @click="RemoveItems" >Remove Items</button>
      <!-- <p>  {{search}} </p> -->
     <ul>
         <li v-for="(item,index) in searchFunc" :key="index"   >       <!-- :key = "item.id " -->      
             {{item.name}}                                             <!--  {{item.id}} -->
             <button v-on:click="DeleteItem(index)" >Delete</button>       <!--  DeleteItem(item.id) -->
             <button v-on:click="EditItem(index)">Edit</button>            <!--  UpdateItem(item.id) -->
         </li>
     </ul>
      <!-- <todo-list/> -->
  </div>
</template>

<script>
//import {uuid} from "vue-uuid";
//import TodoList from './TodoList.vue'
export default {
        name: "TodoInput",
         components: { 
         //    TodoList
        },
        data(){
            return{
                id : '',
                name : "",
                editname:"",
                search : '',
                list : [],
                isDisabled:true,
                select:'',
                highlight: 'background-color : red ; color : white'
            }           
        },

        methods:{
                HandleSubmit(e){
                    e.preventDefault()
                   // console.log("added")
                   // console.log(this.name)
                  //  this.list = this.name

                //     if (this.name.length === 0) return;

                //   if (this.editname != null) {
                //     this.list[this.editname].name = this.name;
                //     this.editname = '';
                //     }
                //   else{
                    //  }
                  //  this.isDisabled = false
                    if(this.name.length > 0){
                     let z =  this.list.push({id:new Date().getTime().toString() , name : this.name})
                     console.log(z)
                    }
                    else{
                        alert('add some data')
                    }
              
               // console.log(aa)
                    this.name = ''
                },

                DeleteItem(idd){
                    console.log('deleted')
                //  let del =   this.list.splice(
                //  this.list.findIndex(function (t) {
                // return t.id !== idd;
                //      }))

                //this.list(del)
                // this.list.$remove(idd)

              //  let del = this.list.splice(this.list.indexOf(idd,1)) 

                    let del = this.list.splice(idd,1)      //splice(position,No.of.item remove)
                                   
                    // let del = this.list.filter((itemId)=>{
                    //       return idd !== itemId.id  
                    // })
                     console.log(del)
                   
                },

                EditItem(idd){
                    console.log('edit')
                    
                    this.isDisabled = false
                    
                    this.name = this.list[idd].name
                    this.editname = idd           //this.name 
                    console.log(this.editname)

                    // let edit = this.list.find((item)=>{
                    //         return idd === item.id
                    // })
                   // this.list.push(this.edit)
                   // console.log(edit)
                   
                },

                UpdatedItem(){
                        console.log('updated')
                        this.isDisabled = true
                        if (this.name.length === 0) return;
                        if (this.editname != null) {
                            this.list[this.editname].name = this.name;
                           // this.editname = '';
                        }
                        // this.editname = '';
                        this.name = ''
                },

                RemoveItems(){
                    // console.log('removed all items')
                    this.list = []
                }
        },

        computed:{
                searchFunc(){
                    // not working
                    // return ( this.list.filter((item)=>{  (item.body.includes(this.search))}) )

                    //working
                      return this.list.filter((item) => { 
                       return( item.name.toLowerCase().includes(this.search.toLowerCase()))
                       })         

                    //working
                    //    return this.list.filter((searchItem)=>{
                    //      return ( searchItem.name.toLowerCase().match(this.search.toLowerCase())  )
                    //    })         
                }

            

        },

        watch:{

        }

}
</script>

<style>
.TodoInput{
    display: inline-block;
}
.highlightText{
    background-color: yellow;  
}
.select{
    width: 200px;
    height: 30px;
}
</style>