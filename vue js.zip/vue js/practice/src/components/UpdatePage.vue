<template>
  <div class="update">
      update 
      <todo-list/>
  </div>
</template>

<script>

import TodoList from './TodoList.vue'
export default {
    name : "UpdatePage",
  components: {  TodoList },

}
</script>

<style>
.update{
  display: inline-grid;
}
</style>