import { createRouter  } from "vue-router";
import { createWebHistory } from "vue-router";
import HomePage from './HomePage';
import UpdatePage from './UpdatePage';

const routes = [
      {
          component : HomePage,
          path : '/',
          name : 'HomePage'
      },
      {
        component : UpdatePage,
        path : '/update',
        name : 'UpdatePage'
    },
]

const router = createRouter({
    history : createWebHistory(),
    routes
})

export default router;